# AWS PACHA

Este paquete contiene funciones para:
- Leer tablas desde fuentes JDBC usando Spark.
- Limpiar carpetas en S3.
- Escribir DataFrames en S3 usando AWS Glue.

## Instalacion
```bash
pip install awspacha
